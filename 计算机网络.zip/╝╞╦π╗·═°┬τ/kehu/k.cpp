#include <iostream>
#include <winsock2.h>
#include <fstream>
#pragma comment(lib, "ws2_32.lib")
using namespace std;
const int DEFAULT_PORT = 21;
const int BUFFER_SIZE = 1024;

int main(int argc, char* argv[]) {
    // Initialize Winsock
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        std::cerr << "WSAStartup failed: " << iResult << std::endl;
        return 1;
    }

    // Create a socket for connecting to the server
    SOCKET connectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (connectSocket == INVALID_SOCKET) {
        std::cerr << "socket failed with error: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    // Resolve the server address and port
    sockaddr_in service;
    service.sin_family = AF_INET;
    service.sin_addr.s_addr = inet_addr("127.0.0.1");
    service.sin_port = htons(DEFAULT_PORT);

    // Connect to the server
    if (connect(connectSocket, (SOCKADDR*)&service, sizeof(service)) == SOCKET_ERROR) {
        std::cerr << "connect failed with error: " << WSAGetLastError() << std::endl;
        closesocket(connectSocket);
        WSACleanup();
        return 1;
    }

    std::cout << "Connected to FTP server at " << inet_ntoa(service.sin_addr) << ":" << DEFAULT_PORT << std::endl;

    // Receive welcome message from server
   
    
    while(true){
    	cout<<"�������ļ�Ŀ¼��\n";
		char recvBuffer[BUFFER_SIZE];
    	int bytesReceived = recv(connectSocket, recvBuffer, BUFFER_SIZE, 0);
    	cout<<bytesReceived<<'\n';
    	if (bytesReceived == SOCKET_ERROR) {
        	std::cerr << "recv failed with error: " << WSAGetLastError() << std::endl;
        	closesocket(connectSocket);
        	WSACleanup();
        	return 1;
    	}
    	recvBuffer[bytesReceived] = '\0';
    	string mulu=recvBuffer; 
    	std::cout << mulu;
    	cout<<"��ѡ������������Ӧ��ţ�\n";
    	cout<<"1 �����ļ�\n";
    	cout<<"2 ɾ���ļ�\n";
    	cout<<"3 �ϴ��ļ�\n";
    	cout<<"4 �����ļ�\n";
    	cout<<"5 �˳�ϵͳ\n";
    	char* q=new char[64];
    	cin>>q;
    	send(connectSocket, q, strlen(q), 0);
    	if(q[0]=='1'){
    		cout<<"���봴���ļ����ļ������ƣ���������ļ������򸽴�·����\n";
    		cout<<"���磺a/a2.txt\n"; 
    		char* q1=new char[64];
    		cin>>q1;
    		send(connectSocket, q1, strlen(q1), 0);
		}else if(q[0]=='2'){
    		cout<<"����ɾ���ļ����ļ������ƣ���������ļ������򸽴�·����\n";
    		cout<<"���磺a/a.txt\n"; 
    		char* q1=new char[64];
    		cin>>q1;
    		send(connectSocket, q1, strlen(q1), 0);
		}else if(q[0]=='3'){
    		cout<<"�����ϴ��ļ����·�������ڸ�Ŀ¼��������'.'��\n";
    		cout<<"���磺a\n"; 
    		char* q1=new char[64];
    		cin>>q1;
    		if(q1[0]=='.'){
    			q1="";
			} 
    		send(connectSocket, q1, strlen(q1), 0);
    		cout<<"������ϴ��ļ�����·����\n";
    		char* q2=new char[64];
    		cin>>q2;
    		send(connectSocket, q2, strlen(q2), 0);
    		
    		ifstream input(q2, ios::in | ios::binary);
	        input.seekg(0, input.end);
	    	int len = input.tellg();
    		char *buffer = new char[len+1];
    		input.close();
    		
    		// Open input file for reading
    		ifstream in(q2, ios::in | ios::binary);
    		in.read(buffer,len);
    		buffer[len]='\0';
    		in.close();
    		
    		//cout<<buffer<<'\n';
    		send(connectSocket, buffer, strlen(buffer), 0);
		}else if(q[0]=='4'){
    		cout<<"���������ļ����ƣ���������ļ������򸽴�·����\n";
    		cout<<"���磺a/a.txt\n"; 
    		char* q2=new char[64];
    		cin>>q2;
    		//cout<<q2<<'\n';
    		send(connectSocket, q2, strlen(q2), 0);
    		char* q4=new char[64];
    		for(int i=strlen(q2)-1;i>=0;i--){
    			if(q2[i]=='/'){
    				for(int j=i+1;j<strlen(q2);j++){
    					q4[j-i-1]=q2[j];
					}
					q4[strlen(q2)-i-1]='\0';
					break;
				}else if(i==0){
					for(int j=i;j<strlen(q2);j++){
    					q4[j-i]=q2[j];
					}
					q4[strlen(q2)-i]='\0';
					break;
				}
			}
			FILE* fp;
			fp=fopen(q4, "w");
			//cout<<q4<<'\n';
			int bytesReceived = recv(connectSocket, recvBuffer, BUFFER_SIZE, 0);
	    	if (bytesReceived == SOCKET_ERROR) {
	        	std::cerr << "recv failed with error: " << WSAGetLastError() << std::endl;
	        	closesocket(connectSocket);
	        	WSACleanup();
	        	return 1;
	    	}
	    	recvBuffer[bytesReceived] = '\0';
	    	const char* res=recvBuffer;
	    	fprintf(fp,res);
			fclose(fp);
			
			send(connectSocket, q2, strlen(q2), 0);
		}else break; 
	}

    // TODO: Send USER, PASS, SYST, TYPE, PWD, CWD, PORT, LIST, RETR commands and handle server responses

    // Close the socket and cleanup Winsock
    closesocket(connectSocket);
    WSACleanup();

    return 0;
}
