#include <iostream>
#include <winsock2.h>
#include <io.h>
#include <windows.h>
#include <fstream>
#pragma comment(lib, "ws2_32.lib")
using namespace std;

const int DEFAULT_PORT = 21;
const int MAX_CLIENTS = 10;
const int BUFFER_SIZE = 1024;

SOCKET clientSocket;

char st[1024];
int sl;
void dfs(char* s0,int d){
	char s[64];
	for(int i=0;i<strlen(s0);i++)
		s[i]=s0[i];
	s[strlen(s0)]='\0';
	strcat(s,"*.*");
	struct _finddata_t z;
	long f=_findfirst(s,&z);
	int p=f;
	_findnext(f,&z);
	_findnext(f,&z);
	while(p!=-1){
		for(int i=1;i<=d;i++){
			for(int j=0;j<2;j++){
				st[sl++]=' ';
			}
		}
		for(int i=0;i<strlen(z.name);i++){
			st[sl++]=z.name[i];
		}
		if(z.attrib==_A_SUBDIR)
			st[sl++]=':';
		st[sl++]='\n';
		if(z.attrib==_A_SUBDIR){
			char zs[64];
			for(int i=0;i<strlen(s);i++)
				zs[i]=s0[i];
			zs[strlen(s)]='\0';
			strcat(zs,z.name);
			strcat(zs,"/");
			dfs(zs,d+1);
		}
		p=_findnext(f,&z);
	}
	_findclose(f);
} 

string duru(){
	char recvBuffer[BUFFER_SIZE];
	int bytesReceived = recv(clientSocket, recvBuffer, BUFFER_SIZE, 0);
	cout<<bytesReceived<<'\n';
	if (bytesReceived == SOCKET_ERROR) {
	    std::cerr << "recv failed with error: " << WSAGetLastError() << std::endl;
	    closesocket(clientSocket);
	    WSACleanup();
	    return "!";
	}
	recvBuffer[bytesReceived] = '\0';
	string res=recvBuffer;
	return res;
}

string hebing(const char* a,const char* b){
	char c[64];
	for(int i=0;i<strlen(a);i++)
		c[i]=a[i];
	c[strlen(a)]='\0';
	strcat(c,b);
	string res=c;
	cout<<res<<'\n';
	return res;
}

int main() {
    // Initialize Winsock
    WSADATA wsaData;
    int iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (iResult != 0) {
        std::cerr << "WSAStartup failed: " << iResult << std::endl;
        return 1;
    }

    // Create a socket for listening
    SOCKET listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listenSocket == INVALID_SOCKET) {
        std::cerr << "socket failed with error: " << WSAGetLastError() << std::endl;
        WSACleanup();
        return 1;
    }

    // Bind the socket to a local address and port
    sockaddr_in service;
    service.sin_family = AF_INET;
    service.sin_addr.s_addr = INADDR_ANY;
    service.sin_port = htons(DEFAULT_PORT);

    if (bind(listenSocket, (SOCKADDR*)&service, sizeof(service)) == SOCKET_ERROR) {
        std::cerr << "bind failed with error: " << WSAGetLastError() << std::endl;
        closesocket(listenSocket);
        WSACleanup();
        return 1;
    }

    // Start listening on the socket
    if (listen(listenSocket, MAX_CLIENTS) == SOCKET_ERROR) {
        std::cerr << "listen failed with error: " << WSAGetLastError() << std::endl;
        closesocket(listenSocket);
        WSACleanup();
        return 1;
    }

    std::cout << "FTP server is listening on port " << DEFAULT_PORT << "..." << std::endl;

    // Accept and handle incoming client connections
    while (true) {
        clientSocket = accept(listenSocket, NULL, NULL);
        if (clientSocket == INVALID_SOCKET) {
            std::cerr << "accept failed: " << WSAGetLastError() << std::endl;
            closesocket(listenSocket);
            WSACleanup();
            return 1;
        }

        std::cout << "New client connected!" << std::endl;

		while(true){
	        char* test="./g/";
			sl=0;
			dfs(test,0);
			cout<<st<<'\n';
	        send(clientSocket, st, strlen(st), 0);
	        string dr=duru();
	    	const char* q=dr.c_str();
	    	cout<<q<<'\n';
	    	if(q[0]=='1'){
	    		string dr=duru();
	    		const char* q1=dr.c_str();
	    		bool tp=0;
	    		for(int i=strlen(q1)-1;i>=0&&q1[i]!='/';i--){
	    			if(q1[i]=='.'){
	    				tp=1;
	    				break;
					}
				}
				if(!tp){
					const char* path=hebing(test,q1).c_str();
					CreateDirectory(path, NULL);
				}else{
	    			FILE* fp;
					fp=fopen(hebing(test,q1).c_str(), "w");
					fclose(fp);
				}
			}else if(q[0]=='2'){
	    		string dr=duru();
	    		const char* q1=dr.c_str();
	    		const char* path=hebing(test,q1).c_str();
	    		remove(path);
			}else if(q[0]=='3'){
	    		string dr=duru();
	    		const char* q1=dr.c_str();
	    		//cout<<q1<<'\n';
	    		string dr2=duru();
	    		const char* q2=dr2.c_str();
	    		char* q4=new char[64];
	    		for(int i=strlen(q2)-1;i>=0;i--){
	    			cout<<i<<' '<<q2[i]<<'\n';
	    			if(q2[i]=='/'){
	    				for(int j=i;j<strlen(q2);j++){
	    					q4[j-i]=q2[j];
						}
						q4[strlen(q2)-i]='\0';
						break;
					}else if(i==0){
						q4[0]='/';
						for(int j=i;j<strlen(q2);j++){
	    					q4[j-i+1]=q2[j];
						}
						q4[strlen(q2)-i+1]='\0';
						cout<<q4<<'\n';
						break;
					}
				}
	    		const char* q3=hebing(q1,q4).c_str();
	    		FILE* fp;
	    		cout<<q3<<'\n';
				fp=fopen(hebing(test,q3).c_str(), "w");
				
				string dr3=duru();
				const char* shuchu=new char[BUFFER_SIZE];
				shuchu=dr3.c_str();
				cout<<dr3<<'\n';
				fprintf(fp,shuchu);
				fclose(fp);
			}else if(q[0]=='4'){
	    		string dr=duru();
	    		const char* q2=dr.c_str();
	    		const char* q1=hebing(test,q2).c_str();
	    		ifstream input(q1, ios::in | ios::binary);
		        input.seekg(0, input.end);
		    	int len = input.tellg();
	    		char *buffer = new char[len+1];
	    		input.close();
	    		
	    		// Open input file for reading
	    		ifstream in(q1, ios::in | ios::binary);
	    		in.read(buffer,len);
	    		buffer[len]='\0';
	    		in.close();
	    		cout<<buffer<<'\n';
	    		send(clientSocket, buffer, strlen(buffer), 0);
	    		duru();
			}else break;
		} 

        // TODO: Handle client commands and data transfer

        // Close client socket
        closesocket(clientSocket);
    }

    // Close listening socket and cleanup Winsock
    closesocket(listenSocket);
    WSACleanup();

    return 0;
}

//g++ f.cpp -lws2_32 -o f
