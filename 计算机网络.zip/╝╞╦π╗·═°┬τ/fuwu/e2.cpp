#include<bits/stdc++.h>
#include <io.h>
using namespace std;
char st[1024];
int sl;
void dfs(char* s0,int d){
	char s[64];
	for(int i=0;i<strlen(s0);i++)
		s[i]=s0[i];
	s[strlen(s0)]='\0';
	strcat(s,"/*.*");
	struct _finddata_t z;
	long f=_findfirst(s,&z);
	int p=f;
	_findnext(f,&z);
	_findnext(f,&z);
	while(p!=-1){
		for(int i=1;i<=d;i++){
			for(int j=0;j<2;j++){
				st[sl++]=' ';
			}
		}
		for(int i=0;i<strlen(z.name);i++){
			st[sl++]=z.name[i];
		}
		if(z.attrib==_A_SUBDIR)
			st[sl++]=':';
		st[sl++]='\n';
		if(z.attrib==_A_SUBDIR){
			char zs[64];
			for(int i=0;i<strlen(s);i++)
				zs[i]=s0[i];
			zs[strlen(s)]='\0';
			strcat(zs,"/");
			strcat(zs,z.name);
			dfs(zs,d+1);
		}
		p=_findnext(f,&z);
	}
	_findclose(f);
} 
int main(){
	char* test="./g";
	sl=0;
	dfs(test,0);
	cout<<st;
	
    return 0;
}
